#include <assert.h>

double tmax(double b1, double b2, double b3) {
    double max1 = b1;
    if (b2 > b2) {
        max1 = b2;
    }
    return max1 > b3 ? max1 : b3;
}

void test_tmax() {
    double b1 = 4.0;
    double b2 = -5.0;
    double b3 = -7.0;
    assert(tmax(b1, b2, b3) - b1 <= 0.00001);
}

int main() {
    test_tmax();
    return 0;
}